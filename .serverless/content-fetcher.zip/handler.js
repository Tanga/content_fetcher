'use strict';
var AWS = require('aws-sdk')
AWS.config.region = 'us-east-1'
var s3 = new AWS.S3()
const uuidV1 = require('uuid/v1')
var http = require('http')
var URL = require('url')

module.exports.fetch = (event, context, callback) => {
  var body = JSON.parse(event.body);
  var url = body.url;
  var metadata = body.s3_metadata;
  var bucket = body.s3_bucket;
  var uri = URL.parse(url);
  http.get({
    hostname: uri.hostname,
    path: uri.pathname
  }, function(res) {
    if(res.statusCode != 200) {
      throw "Received invalid status: " + res.statusCode;
    }

    uploadToS3(bucket, res, metadata, function(s3Url) {
      var response = {
        statusCode: 200,
        headers: {},
        body: JSON.stringify({
          s3_url: s3Url
        }),
      };

      callback(null, response);
    });
  });
};

function uploadToS3 (bucket, res, metadata, s3Callback) {
  res.on('end', function () {
    var params = {
      Body: res.read(),
      Bucket: bucket,
      Key: uuidV1(),
      Metadata: metadata,
      ACL: 'public-read',
      ContentType: res.headers['content-type'],
      ContentDisposition: 'inline'
    };

    var upload = s3.upload(params).promise();

    upload.then(function(result) {
      s3Callback(result.Location);
    }).catch(function(error){
      console.log("error", error);
      throw error;
    });
  });
}
